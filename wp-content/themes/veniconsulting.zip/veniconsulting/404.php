<?php get_header(); ?>
<h2>Die angeforderte Seite wurde leider nicht gefunden!</h2>
<p class="py-4"></p>
<p>Bei Fragen Kontaktieren Sie uns gerne über das <a href="/kontakt">Kontaktformular</a>.</p>
<p><a href="/">Hier</a> gehts zurück zur Startseite!</p>
<p>Außerdem finden Sie <a href="/blog">hier</a> unseren aktuellen Blog.</p>
<?php get_footer(); ?>